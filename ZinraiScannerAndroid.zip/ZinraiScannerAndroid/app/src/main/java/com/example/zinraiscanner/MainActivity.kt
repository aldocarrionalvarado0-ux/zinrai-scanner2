package com.example.zinraiscanner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

private val Navy = Color(0xFF07151B)
private val Panel = Color(0xFF10252D)
private val Teal = Color(0xFF20C997)
private val Red = Color(0xFFFF6577)
private val Muted = Color(0xFF9EB0B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(
            background = Navy, surface = Panel, primary = Teal, onBackground = Color.White,
            onSurface = Color.White
        )) { ScannerScreen() } }
    }
}

data class ScanRow(
    val symbol: String, val price: Double, val change: Double,
    val trend: String, val rsi: Double, val signal: String, val source: String
)

class ScannerViewModel : ViewModel() {
    var rows by mutableStateOf<List<ScanRow>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var message by mutableStateOf("Preparando escáner…"); private set
    var interval by mutableStateOf("1min"); private set

    init { refresh() }

    fun setInterval(value: String) { interval = value; refresh() }

    fun refresh() {
        viewModelScope.launch {
            loading = true
            val apiKey = BuildConfig.TWELVE_DATA_API_KEY
            if (apiKey.isBlank()) {
                rows = DemoScanner.rows()
                message = "MODO DEMO · Datos ilustrativos, no son cotizaciones reales. Configura una clave Twelve Data para datos de mercado."
            } else {
                try {
                    rows = MarketRepository(apiKey).scan(interval)
                    message = "Datos recibidos del proveedor. La disponibilidad y retraso dependen de tu plan."
                } catch (e: Exception) {
                    rows = DemoScanner.rows()
                    message = "No se pudo cargar el mercado: ${e.message ?: "error"}. Mostrando datos DEMO."
                }
            }
            loading = false
        }
    }
}

@Composable
fun ScannerScreen(vm: ScannerViewModel = viewModel()) {
    val intervals = listOf("1min", "5min", "15min", "1h", "4h")
    Surface(Modifier.fillMaxSize(), color = Navy) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ZiNRAi", style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Light, color = Color.White)
                    Text("TRADING SCANNER · EDU", color = Teal, style = MaterialTheme.typography.labelSmall)
                }
                Button(onClick = { vm.refresh() }, enabled = !vm.loading) {
                    Text(if (vm.loading) "..." else "Actualizar")
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("ESCÁNER DE MERCADO", color = Muted, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                intervals.forEach { item ->
                    FilterChip(selected = vm.interval == item, onClick = { vm.setInterval(item) },
                        label = { Text(item.uppercase()) })
                }
            }
            Spacer(Modifier.height(14.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("FOREX + ORO", color = Teal, fontWeight = FontWeight.Bold)
                    Text("EMA 9/21 · RSI 14 · MACD (base EMA)", color = Muted,
                        style = MaterialTheme.typography.bodySmall)
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                HeaderCell("ACTIVO"); HeaderCell("PRECIO"); HeaderCell("RSI"); HeaderCell("SEÑAL")
            }
            Spacer(Modifier.height(6.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                items(vm.rows) { row -> ScanCard(row) }
            }
            Text(vm.message, color = Muted, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Text("Solo con fines educativos. No es asesoramiento financiero ni ejecuta operaciones.",
                color = Muted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable private fun HeaderCell(text: String) {
    Text(text, color = Muted, style = MaterialTheme.typography.labelSmall)
}

@Composable private fun ScanCard(row: ScanRow) {
    val signalColor = when(row.signal) { "ALCISTA" -> Teal; "BAJISTA" -> Red; else -> Color(0xFFFFC857) }
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1.2f)) {
                Text(row.symbol, fontWeight = FontWeight.Bold)
                Text(row.trend, color = Muted, style = MaterialTheme.typography.labelSmall)
            }
            Column(Modifier.weight(1f)) {
                Text("%.5f".format(row.price), style = MaterialTheme.typography.bodyMedium)
                Text("%+.2f%%".format(row.change), color = if (row.change >= 0) Teal else Red,
                    style = MaterialTheme.typography.labelSmall)
            }
            Text("%.0f".format(row.rsi), modifier = Modifier.weight(.5f), color = Color.White)
            Text(row.signal, modifier = Modifier.weight(.9f), color = signalColor,
                fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
        }
    }
}

data class Candle(val close: Double)
data class TimeSeriesResponse(val values: List<Value>?, val status: String?, val message: String?)
data class Value(val close: String)

interface TwelveDataService {
    @retrofit2.http.GET("time_series")
    suspend fun timeSeries(
        @retrofit2.http.Query("symbol") symbol: String,
        @retrofit2.http.Query("interval") interval: String,
        @retrofit2.http.Query("outputsize") outputSize: Int = 100,
        @retrofit2.http.Query("apikey") apiKey: String
    ): TimeSeriesResponse
}

class MarketRepository(private val apiKey: String) {
    private val service = retrofit2.Retrofit.Builder()
        .baseUrl("https://api.twelvedata.com/")
        .addConverterFactory(retrofit2.converter.gson.GsonConverterFactory.create())
        .build().create(TwelveDataService::class.java)

    suspend fun scan(interval: String): List<ScanRow> {
        val symbols = listOf("EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD", "XAU/USD")
        return symbols.map { symbol ->
            val response = service.timeSeries(symbol, interval, 100, apiKey)
            val closes = response.values?.mapNotNull { it.close.toDoubleOrNull() }?.reversed()
                ?: throw IllegalStateException(response.message ?: "Sin datos para $symbol")
            if (closes.size < 30) throw IllegalStateException("Historial insuficiente para $symbol")
            Indicators.analyze(symbol, closes, "Twelve Data")
        }
    }
}

object Indicators {
    private fun ema(values: List<Double>, period: Int): Double {
        val k = 2.0 / (period + 1)
        return values.drop(1).fold(values.first()) { acc, v -> v * k + acc * (1 - k) }
    }
    private fun rsi(values: List<Double>, period: Int = 14): Double {
        val changes = values.takeLast(period + 1).zipWithNext { a, b -> b - a }
        val gains = changes.filter { it > 0 }.sum() / period
        val losses = -changes.filter { it < 0 }.sum() / period
        if (losses == 0.0) return 100.0
        return 100.0 - (100.0 / (1.0 + gains / losses))
    }
    fun analyze(symbol: String, closes: List<Double>, source: String): ScanRow {
        val fast = ema(closes.takeLast(30), 9)
        val slow = ema(closes.takeLast(50), 21)
        val rsi = rsi(closes)
        val prev = closes[closes.lastIndex - 1]
        val last = closes.last()
        val trend = if (fast > slow) "Tendencia alcista" else "Tendencia bajista"
        val signal = when {
            fast > slow && rsi in 50.0..68.0 -> "ALCISTA"
            fast < slow && rsi in 32.0..50.0 -> "BAJISTA"
            else -> "NEUTRAL"
        }
        return ScanRow(symbol, last, ((last - prev) / prev) * 100, trend, rsi, signal, source)
    }
}

object DemoScanner {
    fun rows(): List<ScanRow> {
        val symbols = listOf("EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD", "XAU/USD")
        return symbols.mapIndexed { i, s ->
            val base = if (s == "XAU/USD") 2350.0 else listOf(1.08, 1.27, 149.2, .66, 1.36)[i % 5]
            val wave = (i - 2) * .13
            ScanRow(s, base * (1 + wave / 100), wave, if (i % 2 == 0) "Tendencia alcista" else "Tendencia bajista",
                42.0 + i * 5.0, if (i % 3 == 0) "ALCISTA" else if (i % 3 == 1) "BAJISTA" else "NEUTRAL", "DEMO")
        }
    }
}

# ZiNRAi Scanner EDU (Android)

Proyecto inicial Android nativo en Kotlin + Jetpack Compose. Incluye un panel oscuro de escaneo educativo para EUR/USD, GBP/USD, USD/JPY, AUD/USD, USD/CAD y XAU/USD, temporalidades 1m, 5m, 15m, 1h y 4h, EMA 9/21 y RSI 14.

## Abrir
1. Descomprime el ZIP.
2. Abre la carpeta `ZinraiScannerAndroid` en Android Studio.
3. Usa JDK 17 y deja que Gradle sincronice.
4. Ejecuta en un emulador o teléfono Android.

## Modo DEMO y datos de mercado
- Sin clave API, la app muestra valores ilustrativos etiquetados como DEMO.
- Para solicitar datos de Twelve Data, crea una clave en https://twelvedata.com/ y añade esta línea a `~/.gradle/gradle.properties`:
  `TWELVE_DATA_API_KEY=TU_CLAVE`
- Sincroniza Gradle y vuelve a ejecutar. La cobertura de Forex/oro, límites de llamadas y retrasos dependen del plan del proveedor. No publiques ni compartas tu clave.

## Alcance
La app analiza datos y muestra estados técnicos educativos. No envía órdenes, no se conecta a una cuenta de broker y no garantiza resultados. La lógica de señal es una regla sencilla de ejemplo, no una estrategia validada. Revisa las condiciones del proveedor antes de usar datos en tiempo real.

## Nota
El nombre y diseño son una inspiración funcional general de un escáner financiero oscuro; no copia activos, código ni marca registrada de terceros.
